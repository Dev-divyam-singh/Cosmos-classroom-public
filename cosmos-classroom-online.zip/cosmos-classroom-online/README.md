# Cosmos Classroom Online

A browser-based classroom starter project with:
- teacher password and student classroom password
- teacher approval for student join requests
- real-time shared whiteboard strokes
- study chat
- bilingual starter science lessons (English/Hindi)
- basic screen-capture button using the browser's permission prompt

## Important status

This is a deployable **starter**, not a finished production education platform. Screen capture permission works in supported browsers on HTTPS, but remote screen viewing is not implemented end-to-end yet. For that, add WebRTC peer connections plus a STUN/TURN service and signaling logic. Board history is held in server memory and resets when the server restarts. There is no persistent user database, moderation log, NCERT file hosting, or robust rate limiting yet.

## Run locally

1. Install Node.js 18 or newer.
2. In this folder run `npm install`.
3. Set two environment variables before starting:
   - `ROOM_PASSWORD` — student room password
   - `TEACHER_PASSWORD` — teacher password
4. Run `npm start`.
5. Open `http://localhost:3000` in your browser.

Example environment variables:
- macOS/Linux:
  `ROOM_PASSWORD='your-long-room-password' TEACHER_PASSWORD='your-different-teacher-password' npm start`
- Windows PowerShell:
  `$env:ROOM_PASSWORD='your-long-room-password'; $env:TEACHER_PASSWORD='your-different-teacher-password'; npm start`

Do not use the fallback passwords in `server.js` on a public deployment.

## Deploy online (Render or another Node.js host)

1. Create a private Git repository and upload these project files.
2. Create a new **Node web service** from that repository.
3. Build command: `npm install`
4. Start command: `npm start`
5. Add environment variables in the host dashboard:
   - `ROOM_PASSWORD`
   - `TEACHER_PASSWORD`
6. Deploy. Use the HTTPS URL provided by the host.
7. Open the URL as teacher first. Share the student password privately with the class.

Choose a host that supports long-lived WebSocket connections for Socket.IO. If you use multiple server instances, configure a shared Socket.IO adapter and persistent data store.

## Security and production checklist

Before inviting real students:
- use strong, unique secrets; rotate them if shared widely
- add persistent user accounts, session protections and database-backed permissions
- use HTTPS only
- add rate limiting, input validation, abuse reporting and teacher moderation
- consider student privacy, consent and local school policies before screen sharing
- add WebRTC signaling plus STUN/TURN for actual remote screen sharing
- test reconnects, mobile browsers, keyboard access and low-bandwidth connections
- store approved NCERT materials or link to official NCERT sources; respect copyright and licensing

## Project files

- `server.js`: Node/Express + Socket.IO room, approvals, board relay, chat relay
- `public/index.html`: browser interface and bilingual starter study content
- `.env.example`: environment variable names
