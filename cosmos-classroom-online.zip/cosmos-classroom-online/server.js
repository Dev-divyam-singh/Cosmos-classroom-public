const express = require("express");
const http = require("http");
const { Server } = require("socket.io");

const app = express();
const server = http.createServer(app);
const io = new Server(server, { maxHttpBufferSize: 1e6 });
const PORT = process.env.PORT || 3000;
const TEACHER_PASSWORD = process.env.TEACHER_PASSWORD || "change-this-teacher-password";
const ROOM_PASSWORD = process.env.ROOM_PASSWORD || "change-this-room-password";
const ROOM_ID = "cosmos-main";

app.use(express.static("public"));
app.get("/health", (_req, res) => res.json({ ok: true, service: "Cosmos Classroom" }));

const approved = new Map(); // socket.id -> {name, role}
let boardHistory = [];
const MAX_BOARD_EVENTS = 1800;

function safeName(s) {
  return String(s || "Student").trim().replace(/[<>]/g, "").slice(0, 32) || "Student";
}
function people() {
  return [...approved.entries()].map(([id, u]) => ({ id, name: u.name, role: u.role }));
}
function isTeacher(socket) { return approved.get(socket.id)?.role === "teacher"; }

io.on("connection", socket => {
  socket.on("join:request", (data = {}, reply = () => {}) => {
    const name = safeName(data.name);
    const roomPassword = String(data.password || "");
    if (data.role === "teacher") {
      if (String(data.teacherPassword || "") !== TEACHER_PASSWORD) {
        return reply({ ok: false, error: "Incorrect teacher password." });
      }
      approved.set(socket.id, { name, role: "teacher" });
      socket.join(ROOM_ID);
      socket.emit("room:approved", { role: "teacher", name });
      io.to(ROOM_ID).emit("people:update", people());
      socket.emit("board:history", boardHistory);
      return reply({ ok: true });
    }
    if (roomPassword !== ROOM_PASSWORD) {
      return reply({ ok: false, error: "Incorrect classroom password." });
    }
    const teachersOnline = people().some(p => p.role === "teacher");
    if (!teachersOnline) return reply({ ok: false, error: "The teacher must be online before students can request entry." });
    socket.data.pending = { name };
    io.to(ROOM_ID).emit("join:pending", { id: socket.id, name });
    reply({ ok: true, pending: true });
  });

  socket.on("join:decision", ({ id, allow } = {}) => {
    if (!isTeacher(socket) || typeof id !== "string") return;
    const target = io.sockets.sockets.get(id);
    if (!target || !target.data.pending) return;
    if (!allow) {
      target.emit("room:rejected", { message: "The teacher did not approve this request." });
      target.data.pending = null;
      return;
    }
    const name = target.data.pending.name;
    target.data.pending = null;
    approved.set(id, { name, role: "student" });
    target.join(ROOM_ID);
    target.emit("room:approved", { role: "student", name });
    target.emit("board:history", boardHistory);
    io.to(ROOM_ID).emit("people:update", people());
  });

  socket.on("board:event", event => {
    if (!approved.has(socket.id) || !event || !["line", "clear", "text"].includes(event.type)) return;
    // Bound event size and validate basic fields to avoid oversized payloads.
    if (JSON.stringify(event).length > 6000) return;
    boardHistory.push(event);
    if (boardHistory.length > MAX_BOARD_EVENTS) boardHistory = boardHistory.slice(-MAX_BOARD_EVENTS);
    socket.to(ROOM_ID).emit("board:event", event);
  });

  socket.on("chat:send", data => {
    if (!approved.has(socket.id)) return;
    const message = String(data?.message || "").trim().slice(0, 700);
    if (!message) return;
    io.to(ROOM_ID).emit("chat:message", {
      name: approved.get(socket.id).name,
      role: approved.get(socket.id).role,
      message,
      at: new Date().toISOString()
    });
  });

  socket.on("webrtc:signal", data => {
    if (!approved.has(socket.id) || !data || typeof data.to !== "string") return;
    const target = io.sockets.sockets.get(data.to);
    if (target && approved.has(data.to)) target.emit("webrtc:signal", { from: socket.id, signal: data.signal });
  });

  socket.on("disconnect", () => {
    const wasApproved = approved.has(socket.id);
    approved.delete(socket.id);
    if (socket.data.pending) {
      io.to(ROOM_ID).emit("join:cancelled", { id: socket.id });
    }
    if (wasApproved) {
      io.to(ROOM_ID).emit("people:update", people());
      io.to(ROOM_ID).emit("webrtc:peer-left", { id: socket.id });
    }
  });
});

server.listen(PORT, () => console.log(`Cosmos Classroom listening on ${PORT}`));